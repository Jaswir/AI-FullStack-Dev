function toggleMenu() {
    var menu = document.querySelector('.menu');
    menu.classList.toggle('active');
}

var menuToggle = document.querySelector('.menu-toggle');
menuToggle.style.display = 'block';
